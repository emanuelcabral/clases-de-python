class Perro:
    #constructor de la clase
    def __init__(self, nombre,raza):

        #atributos de la instancia
        self.nombre = nombre
        self.raza = raza

