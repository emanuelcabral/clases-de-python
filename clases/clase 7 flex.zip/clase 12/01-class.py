class Perro:
    pass

perro1 = Perro()
perro2 = Perro()