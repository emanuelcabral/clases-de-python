class Perro:
    pass
