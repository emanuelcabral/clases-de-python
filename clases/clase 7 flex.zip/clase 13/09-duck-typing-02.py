def llama_hablar(x):
    x.hablar()