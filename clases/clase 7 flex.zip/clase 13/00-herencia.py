
#Definimos una clase padre
class Animal:
    pass

#Creamos una clase hija que hereda de la padre
class Perro(Animal):
    pass