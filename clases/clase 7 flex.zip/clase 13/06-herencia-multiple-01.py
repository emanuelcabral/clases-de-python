#Herencia Multiple.
class Clase1:
    pass
class Clase2:
    pass
class Clase3(Clase1, Clase2):
    pass
