#Herencia simple en cadena.

class Clase1:
    pass
class Clase2(Clase1):
    pass
class Clase3(Clase2):
    pass