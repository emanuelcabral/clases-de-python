class Pato:
    def hablar(self):
        print("¡cua!, cua!")

p = Pato()
p.hablar()
#"¡cua!, cua!"