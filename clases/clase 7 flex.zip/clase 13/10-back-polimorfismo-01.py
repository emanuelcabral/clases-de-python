class Animal:
    def hablar(self):
        pass