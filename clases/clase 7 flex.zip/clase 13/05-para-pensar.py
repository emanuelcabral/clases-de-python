#Herencia Multiple.
class Clase1:
    pass
class Clase2:
    pass
class Clase3(Clase1, Clase2):
    pass


# ----------------------------------

#Herencia simple en cadena.

class Clase1:
    pass
class Clase2(Clase1):
    pass
class Clase3(Clase2):
    pass