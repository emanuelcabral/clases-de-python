def llamado_modulo2():
    print("Aca estoy usando el modulo2 :")